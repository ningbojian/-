const IP = "http://124.223.48.212:8000/";
var image = '';

function selectImage(file) {
	if (!file.files || !file.files[0]) {
		return;
	}
	var reader = new FileReader();
	reader.onload = function(evt) {
		document.getElementById('image').src = evt.target.result;
		image = evt.target.result;
	}
	reader.readAsDataURL(file.files[0]);
}

var person = new Vue({
	el: '#person',
	data: {
		nickname: '',
		name: '',
		phone: '',
		deliver: true,
		comment: '',
		comments: ['这是我的第一条评论'],
		editable: true
	},
	//跳转后页面获取参数:
	mounted() {
		console.log(this.$route.query.targetData)
	},
	methods: {
		deliverCM() {
			person.$data.deliver = true
		},
		showall() {
			person.$data.deliver = false
			axios.get(IP + 'user/comment/', {
				params: {
					account: this.$route.query.targrtData,
					action: 'find'
				}
			}).then((res) => {
				person.$data.comments = res.data.msg
			})
		},
		edit(e) {
			var id = e.currentTarget.id
			person.$data.comment = person.$data.comments[id]
			person.$data.deliver = true
			person.$data.old = person.$data.comments[id]
		},
		deleteCM(e) {
			var id = e.currentTarget.id
			var comments = person.$data.comments
			var comment = comments[id]
			comments.splice(id, 1)
			person.$data.comments = comments
			axios.get(IP + 'user/comment/', {
				params: {
					account: this.$route.query.targrtData,
					content: comment,
					action: 'delete'
				}
			}).then((res) => {

			})
		},
		submit() {
			console.log("提交")
			axios.get(IP + 'user/comment/', {
				params: {
					account: this.$route.query.targrtData,
					content: this.old,
					newComment: this.comment,
					action: 'alter'
				}
			}).then((res) => {

			})

		},
		cancel() {
			console.log("取消")
			person.$data.comment = "";
		},
		editcontent() {
			var e = person.$data.editable
			if (e) {
				person.$data.editable = false
			} else {
				person.$data.editable = true
			}
		}
	}
})
