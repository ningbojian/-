function drawmap(id, data, min, max, second) {
	// 基于准备好的dom，初始化echarts实例
	var myChart = echarts.init(document.getElementById(id));
	// 绘制图表
	var option = {
		title: {
			text: second + " 姓",
			left: 'center'
		},
		series: [{
			type: "map",
			name: "人口占比",
			label: {
				show: true,
			},
			mapType: "china",
			data: data,
		}],
		tooltip: {
			show: true,
			trigger: "item",
			triggerOn: "mousemove||click",
			axisPointer: {
				type: "line",
			},
			showContent: true,
			alwaysShowContent: false,
			showDelay: 0,
			hideDelay: 100,
			textStyle: {
				fontSize: 14,
			},
			borderWidth: 0,
			padding: 5,
		},
		visualMap: [{
			min: min,
			max: max,
			text: ['High', 'Low'],
			realtime: false,
			calculable: true,
			inRange: {
				color: ['lightskyblue', 'yellow', 'orangered']
			}
		}],
	};
	myChart.setOption(option);
}

function drawfirst() {
	// 基于准备好的dom，初始化echarts实例
	var myChart = echarts.init(document.getElementById("main"));

	// 指定图表的配置项和数据
	var option = {};

	// 使用刚指定的配置项和数据显示图表。
	myChart.setOption(option);
}
