const IP = "http://101.94.205.0:8000/";

var message = new Vue({
  el: "#message",
  data: {
    content: "<h1 style='text-align: center;color: red'>姓氏人口分布</h1>",
  },
  mounted: function () {
    // drawfirst();
    this.drawLine()
    // this.$nextTick(function () {
    //     // 仅在整个视图都被渲染之后才会运行的代码
    // })
  },
  methods: {
    drawLine() {
      console.log("开始画图");
      axios
        .get(IP + "surname/map/", {
          params: {
            surname: "张",
          },
        })
        .then((res) => {
          console.log("成功", res);
          let data = res.data.data;
		  let min = res.data.min;
		  let max = res.data.max;
          drawmap("myChart", data, min, max, "张");
        })
        .catch((err) => {
          console.log("失败", err);
        });
    },
  },
});
